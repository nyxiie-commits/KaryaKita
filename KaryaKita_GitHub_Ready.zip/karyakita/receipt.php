<?php
require 'functions.php';
need_login();
$id=(int)($_GET['id']??0);
$sql="SELECT o.*,u.name customer,u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id=?";
$args=[$id];
if(user()['role']!=='admin'){$sql.=' AND o.user_id=?';$args[]=user()['id'];}
$s=$pdo->prepare($sql);$s->execute($args);$o=$s->fetch();
if(!$o){http_response_code(404);exit('Pesanan tidak ditemukan.');}
if(empty($o['payment_proof'])){http_response_code(403);exit('Struk baru tersedia setelah bukti pembayaran berhasil diunggah.');}
$s=$pdo->prepare('SELECT product_name,price,quantity FROM order_items WHERE order_id=?');$s->execute([$id]);$items=$s->fetchAll();
$isVerified = $o['payment_status']==='berhasil';
$subtotal = isset($o['subtotal']) ? (float)$o['subtotal'] : array_reduce($items, fn($sum,$it)=>$sum + ($it['price']*$it['quantity']), 0);
$shipping = (float)($o['shipping_cost'] ?? 0);
$courier = $o['shipping_courier'] ?? 'Belum dipilih';
function receipt_date($v){return $v?date('d-m-Y H:i',strtotime($v)):'-';}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Struk Pesanan #<?=$id?> | KaryaKita</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:30px;background:#f7f4eb;color:#382719;font:14px Arial,sans-serif}.receipt{max-width:720px;margin:auto;background:#fff;padding:34px;border:1px solid #eadfc9;border-radius:14px}.brand{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #f3a21b;padding-bottom:18px}.brand h1{margin:0;color:#9b5b12;font-size:28px}.brand p{margin:5px 0;color:#806b55}.paid{background:<?=$isVerified?'#e7f7e9':'#fff2cc'?>;color:<?=$isVerified?'#176b2c':'#8a5a16'?>;padding:9px 14px;border-radius:20px;font-weight:bold}.meta{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:22px 0}.meta div{padding:12px;background:#fff9e9;border-radius:8px}.meta small{display:block;color:#806b55;margin-bottom:5px}.meta b{overflow-wrap:anywhere}table{width:100%;border-collapse:collapse;margin:20px 0}th,td{text-align:left;padding:12px 8px;border-bottom:1px solid #eee}th:last-child,td:last-child{text-align:right}.summary{margin:18px 0 10px auto;max-width:360px}.summary p{display:flex;justify-content:space-between;margin:9px 0}.total{display:flex;justify-content:space-between;text-align:right;font-size:21px;font-weight:bold;color:#9b5b12;padding:12px 0;border-top:1px solid #eadfc9}.foot{border-top:1px dashed #d8c7a8;padding-top:16px;color:#806b55;text-align:center}.actions{text-align:center;margin:20px auto}.btn{border:0;background:#f3a21b;color:#382719;padding:11px 18px;border-radius:8px;font-weight:bold;cursor:pointer;text-decoration:none}@media print{body{background:#fff;padding:0}.receipt{border:0;border-radius:0;padding:12px}.actions{display:none}}
</style></head><body><main class="receipt"><div class="brand"><div><h1>KaryaKita</h1><p>Belanja Lokal, Dukung Karya Indonesia</p><b>STRUK PESANAN / PEMBAYARAN</b></div><span class="paid"><?=$isVerified?'LUNAS / TERVERIFIKASI':'BUKTI DIUNGGAH'?></span></div>
<div class="meta"><div><small>Nomor Pesanan</small><b>#<?=e($o['id'])?></b></div><div><small>Tanggal Pesanan</small><b><?=e(receipt_date($o['created_at']))?></b></div><div><small>Nama Pelanggan</small><b><?=e($o['customer'])?></b></div><div><small>Metode Pembayaran</small><b><?=e($o['payment_method'])?></b></div><div><small>Ekspedisi</small><b><?=e($courier)?></b></div><div><small>Nomor Telepon</small><b><?=e($o['phone'])?></b></div><div style="grid-column:1/-1"><small>Alamat Pengiriman</small><b><?=e($o['address'])?></b></div><div><small>Email</small><b><?=e($o['email'])?></b></div><div><small>Status Pembayaran</small><b><?=e(str_replace('_',' ',$o['payment_status']))?></b></div></div>
<table><thead><tr><th>Produk</th><th>Harga</th><th>Qty</th><th>Subtotal</th></tr></thead><tbody><?php foreach($items as $it):?><tr><td><?=e($it['product_name'])?></td><td><?=rupiah($it['price'])?></td><td><?=e($it['quantity'])?></td><td><?=rupiah($it['price']*$it['quantity'])?></td></tr><?php endforeach;?></tbody></table>
<div class="summary"><p><span>Total produk</span><b><?=rupiah($subtotal)?></b></p><p><span>Ongkos kirim (<?=e($courier)?>)</span><b><?=rupiah($shipping)?></b></p></div>
<div class="total"><span>Total pembayaran</span><span><?=rupiah($o['total'])?></span></div><div class="foot"><?php if($isVerified):?>Pembayaran telah diverifikasi oleh admin KaryaKita.<?php else:?>Bukti pembayaran telah diunggah. Status pembayaran masih menunggu verifikasi admin. Dokumen ini merupakan struk pesanan dan bukan konfirmasi bahwa dana telah diterima.<?php endif;?><br>Terima kasih telah mendukung produk handmade UMKM Indonesia.</div></main><div class="actions"><button class="btn" onclick="window.print()">Cetak / Simpan sebagai PDF</button></div></body></html>
