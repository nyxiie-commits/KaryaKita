Tempat layout MVC baru. Tampilan publik yang berjalan tetap menggunakan header.php/footer.php sampai proses migrasi tiap halaman selesai.
