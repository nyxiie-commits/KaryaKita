<?php
require_once __DIR__ . '/auth.php';

$pageTitle = 'Kelola Kategori';
$error = '';
$editCategory = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT id, name FROM categories WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editCategory = $stmt->fetch();
    if (!$editCategory) {
        flash('Kategori tidak ditemukan.');
        header('Location: kategori.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        $stmt = $pdo->prepare('DELETE FROM categories WHERE id = ?');
        $stmt->execute([$id]);
        flash('Kategori berhasil dihapus. Produk terkait akan menjadi tanpa kategori.');
        header('Location: kategori.php');
        exit;
    }

    $name = trim((string) ($_POST['name'] ?? ''));
    if ($name === '' || mb_strlen($name) > 100) {
        $error = 'Nama kategori wajib diisi dan maksimal 100 karakter.';
    } else {
        try {
            if ($id > 0) {
                $stmt = $pdo->prepare('UPDATE categories SET name = ? WHERE id = ?');
                $stmt->execute([$name, $id]);
                flash('Kategori berhasil diperbarui.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO categories (name) VALUES (?)');
                $stmt->execute([$name]);
                flash('Kategori baru berhasil ditambahkan.');
            }
            header('Location: kategori.php');
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $error = 'Nama kategori tersebut sudah digunakan.';
            } else {
                error_log('[KaryaKita admin kategori] ' . $e->getMessage());
                $error = 'Kategori belum dapat disimpan. Silakan coba lagi.';
            }
        }
    }
}

$categories = $pdo->query(
    'SELECT c.id, c.name, c.created_at, COUNT(p.id) AS product_count
     FROM categories c LEFT JOIN products p ON p.category_id = c.id
     GROUP BY c.id, c.name, c.created_at
     ORDER BY c.name'
)->fetchAll();

require __DIR__ . '/header.php';
?>
<section class="admin-page-heading">
    <div><span class="admin-eyebrow">PENGELOMPOKAN KATALOG</span><h1>Kelola Kategori</h1><p>Buat dan perbarui kategori untuk berbagai jenis produk handmade.</p></div>
</section>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

<section class="admin-card admin-form-card">
    <div class="admin-card-heading">
        <div><h2><?= $editCategory ? 'Edit Kategori' : 'Tambah Kategori' ?></h2><p>Kategori dapat ditambahkan sesuai perkembangan produk UMKM.</p></div>
        <?php if ($editCategory): ?><a class="admin-text-link" href="kategori.php">Batal edit</a><?php endif; ?>
    </div>
    <form method="post" class="admin-category-form">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int) ($editCategory['id'] ?? 0) ?>">
        <input type="text" name="name" maxlength="100" required value="<?= e($editCategory['name'] ?? '') ?>" placeholder="Contoh: Kerajinan Kulit">
        <button class="admin-button admin-button-primary" type="submit"><i class="bi bi-plus-lg"></i> <?= $editCategory ? 'Simpan Perubahan' : 'Tambah Kategori' ?></button>
    </form>
</section>

<section class="admin-card">
    <div class="admin-card-heading"><div><h2>Daftar Kategori</h2><p><?= count($categories) ?> kategori tersedia.</p></div></div>
    <?php if (!$categories): ?>
        <div class="admin-empty"><i class="bi bi-tags"></i><p>Belum ada kategori.</p></div>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Nama Kategori</th><th>Jumlah Produk</th><th>Dibuat</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><strong><?= e($category['name']) ?></strong></td>
                        <td><span class="admin-count-pill"><?= (int) $category['product_count'] ?> produk</span></td>
                        <td><?= e(date('d M Y', strtotime($category['created_at']))) ?></td>
                        <td><div class="admin-actions">
                            <a class="admin-icon-button" href="kategori.php?edit=<?= (int) $category['id'] ?>" title="Edit kategori"><i class="bi bi-pencil-square"></i></a>
                            <form method="post" onsubmit="return confirm('Hapus kategori ini? Produk di dalamnya tidak dihapus, tetapi kategorinya akan dikosongkan.')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $category['id'] ?>">
                                <button class="admin-icon-button danger" type="submit" name="action" value="delete" title="Hapus kategori"><i class="bi bi-trash"></i></button>
                            </form>
                        </div></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/footer.php'; ?>
