<?php
require_once __DIR__ . '/auth.php';

$pageTitle = 'Kelola Produk';
$error = '';
$editProduct = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([(int) $_GET['edit']]);
    $editProduct = $stmt->fetch();
    if (!$editProduct) {
        flash('Produk yang ingin diedit tidak ditemukan.');
        header('Location: produk.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $stmt = $pdo->prepare('SELECT image FROM products WHERE id = ?');
        $stmt->execute([$id]);
        $product = $stmt->fetch();

        if ($product) {
            $delete = $pdo->prepare('DELETE FROM products WHERE id = ?');
            $delete->execute([$id]);

            $imagePath = __DIR__ . '/../uploads/products/' . basename((string) $product['image']);
            if (!empty($product['image']) && is_file($imagePath)) {
                @unlink($imagePath);
            }
            flash('Produk berhasil dihapus.');
        } else {
            flash('Produk tidak ditemukan.');
        }
        header('Location: produk.php');
        exit;
    }

    $id = (int) ($_POST['id'] ?? 0);
    $name = trim((string) ($_POST['name'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
    $stock = filter_var($_POST['stock'] ?? null, FILTER_VALIDATE_INT);
    $categoryId = (int) ($_POST['category_id'] ?? 0);
    $imageName = null;

    if ($name === '' || mb_strlen($name) > 180 || $price === false || $price < 0 || $stock === false || $stock < 0) {
        $error = 'Periksa kembali nama, harga, dan stok produk.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM categories WHERE id = ?');
        $stmt->execute([$categoryId]);
        if ($categoryId > 0 && !$stmt->fetch()) {
            $error = 'Kategori yang dipilih tidak tersedia.';
        }
    }

    if (!$error && isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK || $_FILES['image']['size'] > 3 * 1024 * 1024) {
            $error = 'Foto gagal diunggah atau ukurannya melebihi 3 MB.';
        } else {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['image']['tmp_name']);
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if (!isset($allowed[$mime])) {
                $error = 'Format foto harus JPG, PNG, atau WebP.';
            } else {
                $uploadDir = __DIR__ . '/../uploads/products/';
                if (!is_dir($uploadDir) || !is_writable($uploadDir)) {
                    $error = 'Folder uploads/products belum tersedia atau tidak dapat ditulis.';
                } else {
                    $imageName = 'product_' . bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
                    if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName)) {
                        $error = 'Foto produk gagal disimpan di server.';
                    }
                }
            }
        }
    }

    if (!$error) {
        if ($id > 0) {
            $stmt = $pdo->prepare('SELECT image FROM products WHERE id = ?');
            $stmt->execute([$id]);
            $oldProduct = $stmt->fetch();
            if (!$oldProduct) {
                $error = 'Produk yang akan diperbarui tidak ditemukan.';
            } else {
                $finalImage = $imageName ?: ($oldProduct['image'] ?? null);
                $stmt = $pdo->prepare(
                    'UPDATE products SET category_id = ?, name = ?, description = ?, price = ?, stock = ?, image = ? WHERE id = ?'
                );
                $stmt->execute([$categoryId ?: null, $name, $description, $price, $stock, $finalImage, $id]);

                if ($imageName && !empty($oldProduct['image'])) {
                    $oldPath = __DIR__ . '/../uploads/products/' . basename($oldProduct['image']);
                    if (is_file($oldPath)) @unlink($oldPath);
                }
                flash('Perubahan produk berhasil disimpan.');
                header('Location: produk.php');
                exit;
            }
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO products (category_id, name, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$categoryId ?: null, $name, $description, $price, $stock, $imageName]);
            flash('Produk baru berhasil ditambahkan.');
            header('Location: produk.php');
            exit;
        }
    }

    if ($imageName && is_file(__DIR__ . '/../uploads/products/' . $imageName)) {
        @unlink(__DIR__ . '/../uploads/products/' . $imageName);
    }
}

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$products = $pdo->query(
    'SELECT p.id, p.name, p.price, p.stock, p.image, c.name AS category_name
     FROM products p LEFT JOIN categories c ON c.id = p.category_id
     ORDER BY p.created_at DESC, p.id DESC'
)->fetchAll();

require __DIR__ . '/header.php';
?>
<section class="admin-page-heading">
    <div><span class="admin-eyebrow">KATALOG TOKO</span><h1>Kelola Produk</h1><p>Tambah, perbarui, dan atur stok produk handmade.</p></div>
    <a class="admin-button admin-button-light" href="produk.php"><i class="bi bi-arrow-clockwise"></i> Muat Ulang</a>
</section>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

<section class="admin-card admin-form-card">
    <div class="admin-card-heading">
        <div><h2><?= $editProduct ? 'Edit Produk' : 'Tambah Produk Baru' ?></h2><p>Isi informasi produk yang akan ditampilkan di katalog.</p></div>
        <?php if ($editProduct): ?><a class="admin-text-link" href="produk.php">Batal edit</a><?php endif; ?>
    </div>
    <form method="post" enctype="multipart/form-data" class="admin-form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int) ($editProduct['id'] ?? 0) ?>">
        <label class="admin-field">Nama Produk
            <input type="text" name="name" maxlength="180" required value="<?= e($editProduct['name'] ?? '') ?>" placeholder="Contoh: Vas Bunga Handmade">
        </label>
        <label class="admin-field">Kategori
            <select name="category_id">
                <option value="0">Pilih kategori</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= (int) $category['id'] ?>" <?= (int) ($editProduct['category_id'] ?? 0) === (int) $category['id'] ? 'selected' : '' ?>><?= e($category['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label class="admin-field">Harga (Rp)
            <input type="number" name="price" min="0" step="100" required value="<?= e($editProduct['price'] ?? '') ?>" placeholder="85000">
        </label>
        <label class="admin-field">Stok
            <input type="number" name="stock" min="0" step="1" required value="<?= e($editProduct['stock'] ?? 0) ?>" placeholder="10">
        </label>
        <label class="admin-field admin-field-wide">Deskripsi Produk
            <textarea name="description" rows="4" placeholder="Jelaskan bahan, ukuran, keunikan, dan detail produk..."><?= e($editProduct['description'] ?? '') ?></textarea>
        </label>
        <label class="admin-field admin-field-wide">Foto Produk <small>JPG, PNG, atau WebP. Maksimal 3 MB.</small>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
        </label>
        <?php if (!empty($editProduct['image'])): ?>
            <div class="admin-current-image">
                <img src="../uploads/products/<?= e(rawurlencode(basename($editProduct['image']))) ?>" alt="Foto produk saat ini">
                <span>Foto saat ini. Pilih foto baru jika ingin menggantinya.</span>
            </div>
        <?php endif; ?>
        <div class="admin-field-wide">
            <button class="admin-button admin-button-primary" type="submit"><i class="bi bi-check2-circle"></i> <?= $editProduct ? 'Simpan Perubahan' : 'Tambah Produk' ?></button>
        </div>
    </form>
</section>

<section class="admin-card">
    <div class="admin-card-heading"><div><h2>Daftar Produk</h2><p><?= count($products) ?> produk tercatat dalam katalog.</p></div></div>
    <?php if (!$products): ?>
        <div class="admin-empty"><i class="bi bi-box"></i><p>Belum ada produk. Tambahkan produk pertama melalui formulir di atas.</p></div>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><div class="admin-product-cell">
                            <img src="../uploads/products/<?= e(rawurlencode(basename((string) $product['image']))) ?>" onerror="this.src='https://placehold.co/80x80/fff3c4/7b4b16?text=Produk'" alt="">
                            <strong><?= e($product['name']) ?></strong>
                        </div></td>
                        <td><?= e($product['category_name'] ?? 'Tanpa kategori') ?></td>
                        <td><?= rupiah($product['price']) ?></td>
                        <td><span class="<?= (int) $product['stock'] <= 3 ? 'admin-stock-low' : 'admin-stock' ?>"><?= (int) $product['stock'] ?></span></td>
                        <td><div class="admin-actions">
                            <a class="admin-icon-button" href="produk.php?edit=<?= (int) $product['id'] ?>" title="Edit produk"><i class="bi bi-pencil-square"></i></a>
                            <form method="post" onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $product['id'] ?>">
                                <button class="admin-icon-button danger" type="submit" name="action" value="delete" title="Hapus produk"><i class="bi bi-trash"></i></button>
                            </form>
                        </div></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/footer.php'; ?>
