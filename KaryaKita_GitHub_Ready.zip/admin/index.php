<?php
$pageTitle = 'Dashboard';
require __DIR__ . '/header.php';

$stats = [
    'products' => (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(),
    'categories' => (int) $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn(),
    'customers' => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'pelanggan'")->fetchColumn(),
    'orders' => (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'pending' => (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE payment_status = 'menunggu_verifikasi'")->fetchColumn(),
];
$revenue = (float) $pdo->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE payment_status = 'berhasil'")->fetchColumn();

$recentOrders = $pdo->query(
    'SELECT o.id, o.total, o.payment_status, o.order_status, o.created_at,
            u.name AS customer_name
     FROM orders o
     INNER JOIN users u ON u.id = o.user_id
     ORDER BY o.created_at DESC
     LIMIT 7'
)->fetchAll();

$dailySales = $pdo->query(
    "SELECT DATE(created_at) AS sale_date, SUM(total) AS amount
     FROM orders
     WHERE payment_status = 'berhasil'
       AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
     GROUP BY DATE(created_at)
     ORDER BY sale_date"
)->fetchAll();

$salesMap = [];
foreach ($dailySales as $row) {
    $salesMap[$row['sale_date']] = (float) $row['amount'];
}
$chartLabels = [];
$chartValues = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $chartLabels[] = date('d/m', strtotime($date));
    $chartValues[] = $salesMap[$date] ?? 0;
}

function admin_status_label(string $status): string {
    return match ($status) {
        'berhasil' => 'Terverifikasi',
        'menunggu_verifikasi' => 'Menunggu verifikasi',
        'ditolak' => 'Ditolak',
        'menunggu_pembayaran' => 'Menunggu pembayaran',
        default => ucwords(str_replace('_', ' ', $status)),
    };
}
function admin_status_class(string $status): string {
    return match ($status) {
        'berhasil', 'selesai' => 'status-success',
        'ditolak', 'dibatalkan' => 'status-danger',
        'menunggu_verifikasi', 'menunggu_pembayaran' => 'status-warning',
        default => 'status-info',
    };
}
?>
<section class="admin-page-heading">
    <div>
        <span class="admin-eyebrow">RINGKASAN TOKO</span>
        <h1>Dashboard</h1>
        <p>Selamat datang, <?= e(user()['name'] ?? 'Admin') ?>. Berikut ringkasan aktivitas KaryaKita.</p>
    </div>
    <a class="admin-button admin-button-primary" href="produk.php">
        <i class="bi bi-plus-lg"></i> Tambah Produk
    </a>
</section>

<section class="admin-stat-grid">
    <article class="admin-stat-card">
        <span class="admin-stat-icon icon-gold"><i class="bi bi-box-seam"></i></span>
        <div><small>Total Produk</small><strong><?= number_format($stats['products']) ?></strong><span>Produk dalam katalog</span></div>
    </article>
    <article class="admin-stat-card">
        <span class="admin-stat-icon icon-orange"><i class="bi bi-tags"></i></span>
        <div><small>Total Kategori</small><strong><?= number_format($stats['categories']) ?></strong><span>Kategori aktif</span></div>
    </article>
    <article class="admin-stat-card">
        <span class="admin-stat-icon icon-green"><i class="bi bi-people"></i></span>
        <div><small>Pelanggan</small><strong><?= number_format($stats['customers']) ?></strong><span>Akun pelanggan</span></div>
    </article>
    <article class="admin-stat-card">
        <span class="admin-stat-icon icon-blue"><i class="bi bi-receipt"></i></span>
        <div><small>Total Pesanan</small><strong><?= number_format($stats['orders']) ?></strong><span>Seluruh pesanan masuk</span></div>
    </article>
</section>

<section class="admin-dashboard-grid">
    <article class="admin-card admin-chart-card">
        <div class="admin-card-heading">
            <div><h2>Ringkasan Penjualan</h2><p>Transaksi terverifikasi dalam 7 hari terakhir</p></div>
            <div class="admin-sales-actions">
                <span class="admin-total-revenue"><?= rupiah($revenue) ?></span>
                <form class="admin-export-form" action="export-penjualan.php" method="get">
                    <label><span>Dari</span><input type="date" name="dari" aria-label="Tanggal awal laporan"></label>
                    <label><span>Sampai</span><input type="date" name="sampai" aria-label="Tanggal akhir laporan"></label>
                    <button class="admin-button admin-button-primary" type="submit"><i class="bi bi-file-earmark-excel"></i> Unduh Excel</button>
                </form>
            </div>
        </div>
        <div class="admin-chart-wrap"><canvas id="salesChart" aria-label="Grafik penjualan tujuh hari terakhir"></canvas></div>
    </article>

    <article class="admin-card admin-pending-card">
        <span class="admin-eyebrow">PERLU TINDAKAN</span>
        <div class="pending-number"><?= number_format($stats['pending']) ?></div>
        <h2>Menunggu Verifikasi</h2>
        <p>Pesanan yang sudah mengunggah bukti pembayaran dan perlu diperiksa.</p>
        <a class="admin-button admin-button-primary w-100 justify-content-center" href="pesanan.php">
            Periksa Pesanan <i class="bi bi-arrow-right"></i>
        </a>
    </article>
</section>

<section class="admin-card">
    <div class="admin-card-heading">
        <div><h2>Pesanan Terbaru</h2><p>Aktivitas pesanan yang baru masuk</p></div>
        <a class="admin-text-link" href="pesanan.php">Lihat semua <i class="bi bi-arrow-right"></i></a>
    </div>
    <?php if (!$recentOrders): ?>
        <div class="admin-empty"><i class="bi bi-inbox"></i><p>Belum ada pesanan.</p></div>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead><tr><th>Pesanan</th><th>Pelanggan</th><th>Tanggal</th><th>Total</th><th>Status Pembayaran</th></tr></thead>
                <tbody>
                <?php foreach ($recentOrders as $order): ?>
                    <tr>
                        <td><strong>#<?= (int) $order['id'] ?></strong></td>
                        <td><?= e($order['customer_name']) ?></td>
                        <td><?= e(date('d M Y, H:i', strtotime($order['created_at']))) ?></td>
                        <td><?= rupiah($order['total']) ?></td>
                        <td><span class="admin-status <?= admin_status_class($order['payment_status']) ?>"><?= e(admin_status_label($order['payment_status'])) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const salesCanvas = document.getElementById('salesChart');
if (salesCanvas && window.Chart) {
    new Chart(salesCanvas, {
        type: 'line',
        data: {
            labels: <?= json_encode($chartLabels) ?>,
            datasets: [{
                label: 'Penjualan',
                data: <?= json_encode($chartValues) ?>,
                borderColor: '#e99435',
                backgroundColor: 'rgba(255, 220, 120, .25)',
                fill: true,
                tension: .35,
                pointRadius: 4,
                pointBackgroundColor: '#e99435'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { callback: value => 'Rp' + Number(value).toLocaleString('id-ID') } },
                x: { grid: { display: false } }
            }
        }
    });
}
</script>
<?php require __DIR__ . '/footer.php'; ?>
