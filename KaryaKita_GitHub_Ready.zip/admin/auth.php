<?php
require_once __DIR__ . '/../functions.php';
need_admin();
