</main>
        <footer class="admin-footer">
            <span>KaryaKita Admin</span>
            <span>Kelola toko handmade dan produk UMKM Indonesia.</span>
        </footer>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
