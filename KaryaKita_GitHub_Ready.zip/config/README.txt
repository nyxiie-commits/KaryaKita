Konfigurasi hosting saat ini dibaca dari config.php di root. Simpan kredensial hanya di hosting dan jangan bagikan file berisi password.
