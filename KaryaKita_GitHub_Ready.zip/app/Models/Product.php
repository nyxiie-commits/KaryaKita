<?php
namespace App\Models;
use PDO;
final class Product {
    public function __construct(private PDO $db) {}
    public function all(): array {
        return $this->db->query('SELECT p.*, c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.created_at DESC')->fetchAll();
    }
    public function find(int $id): ?array {
        $q=$this->db->prepare('SELECT p.*, c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?');
        $q->execute([$id]); $row=$q->fetch(); return $row ?: null;
    }
}
