<?php
// Isi dengan detail MySQL dari InfinityFree setelah database dibuat.
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_karyakita');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'ISI_PASSWORD_DATABASE_BARU');
// Untuk instalasi di root domain, biarkan kosong. Jika di subfolder, isi misalnya /karyakita
if (!defined('BASE_URL')) define('BASE_URL', '');
if (session_status() === PHP_SESSION_NONE) session_start();
try { $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
catch(PDOException $e) { http_response_code(500); exit('Koneksi database gagal. Periksa konfigurasi config.php dan pastikan database sudah di-import.'); }
