<?php
require_once __DIR__ . '/auth.php';

$pageTitle = 'Kelola Pesanan';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id <= 0) {
        $error = 'Nomor pesanan tidak valid.';
    } else {
        try {
            if ($action === 'approve') {
                $stmt = $pdo->prepare(
                    "UPDATE orders SET payment_status = 'berhasil', order_status = 'diproses', paid_at = NOW()
                     WHERE id = ? AND payment_status = 'menunggu_verifikasi'"
                );
                $stmt->execute([$id]);
            } elseif ($action === 'reject') {
                $stmt = $pdo->prepare(
                    "UPDATE orders SET payment_status = 'ditolak', order_status = 'menunggu_pembayaran'
                     WHERE id = ? AND payment_status = 'menunggu_verifikasi'"
                );
                $stmt->execute([$id]);
            } elseif ($action === 'ship') {
                $stmt = $pdo->prepare(
                    "UPDATE orders SET order_status = 'dikirim'
                     WHERE id = ? AND payment_status = 'berhasil' AND order_status = 'diproses'"
                );
                $stmt->execute([$id]);
            } elseif ($action === 'complete') {
                $stmt = $pdo->prepare(
                    "UPDATE orders SET order_status = 'selesai'
                     WHERE id = ? AND payment_status = 'berhasil' AND order_status = 'dikirim'"
                );
                $stmt->execute([$id]);
            } else {
                $error = 'Aksi pesanan tidak dikenali.';
            }

            if (!$error) {
                flash($stmt->rowCount() ? 'Status pesanan berhasil diperbarui.' : 'Tidak ada perubahan. Periksa status pesanan saat ini.');
                header('Location: pesanan.php');
                exit;
            }
        } catch (PDOException $e) {
            error_log('[KaryaKita admin pesanan] ' . $e->getMessage());
            $error = 'Status pesanan gagal diperbarui.';
        }
    }
}

$filter = $_GET['status'] ?? '';
$allowedFilters = ['menunggu_pembayaran', 'menunggu_verifikasi', 'berhasil', 'ditolak'];
$sql = 'SELECT o.*, u.name AS customer_name, u.email AS customer_email
        FROM orders o INNER JOIN users u ON u.id = o.user_id';
$params = [];
if (in_array($filter, $allowedFilters, true)) {
    $sql .= ' WHERE o.payment_status = ?';
    $params[] = $filter;
}
$sql .= ' ORDER BY o.created_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

function order_payment_label(string $status): string {
    return match ($status) {
        'berhasil' => 'Terverifikasi',
        'menunggu_verifikasi' => 'Menunggu verifikasi',
        'ditolak' => 'Ditolak',
        default => 'Menunggu pembayaran',
    };
}
function order_badge_class(string $status): string {
    return match ($status) {
        'berhasil' => 'status-success',
        'ditolak' => 'status-danger',
        'menunggu_verifikasi', 'menunggu_pembayaran' => 'status-warning',
        default => 'status-info',
    };
}

require __DIR__ . '/header.php';
?>
<section class="admin-page-heading">
    <div><span class="admin-eyebrow">TRANSAKSI TOKO</span><h1>Kelola Pesanan</h1><p>Periksa bukti pembayaran dan perbarui proses pesanan pelanggan.</p></div>
</section>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

<section class="admin-card">
    <div class="admin-filter-row">
        <a class="<?= $filter === '' ? 'selected' : '' ?>" href="pesanan.php">Semua</a>
        <a class="<?= $filter === 'menunggu_verifikasi' ? 'selected' : '' ?>" href="?status=menunggu_verifikasi">Menunggu verifikasi</a>
        <a class="<?= $filter === 'berhasil' ? 'selected' : '' ?>" href="?status=berhasil">Terverifikasi</a>
        <a class="<?= $filter === 'ditolak' ? 'selected' : '' ?>" href="?status=ditolak">Ditolak</a>
        <a class="<?= $filter === 'menunggu_pembayaran' ? 'selected' : '' ?>" href="?status=menunggu_pembayaran">Belum dibayar</a>
    </div>

    <?php if (!$orders): ?>
        <div class="admin-empty"><i class="bi bi-receipt"></i><p>Tidak ada pesanan pada filter ini.</p></div>
    <?php else: ?>
        <div class="admin-table-wrap">
            <table class="admin-table admin-orders-table">
                <thead><tr><th>Pesanan</th><th>Pelanggan</th><th>Total</th><th>Bukti Pembayaran</th><th>Status</th><th>Tindakan</th></tr></thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><strong>#<?= (int) $order['id'] ?></strong><small class="admin-cell-sub"><?= e(date('d M Y, H:i', strtotime($order['created_at']))) ?></small></td>
                        <td><strong><?= e($order['customer_name']) ?></strong><small class="admin-cell-sub"><?= e($order['customer_email']) ?></small></td>
                        <td><strong><?= rupiah($order['total']) ?></strong></td>
                        <td>
                            <?php if (!empty($order['payment_proof'])): ?>
                                <a class="admin-text-link" href="../uploads/payments/<?= e(rawurlencode(basename($order['payment_proof']))) ?>" target="_blank" rel="noopener"><i class="bi bi-image"></i> Lihat bukti</a>
                            <?php else: ?><span class="text-muted">Belum diunggah</span><?php endif; ?>
                            <div><a class="admin-sub-link" href="../receipt.php?id=<?= (int) $order['id'] ?>" target="_blank" rel="noopener">Buka struk</a></div>
                        </td>
                        <td>
                            <span class="admin-status <?= order_badge_class($order['payment_status']) ?>"><?= e(order_payment_label($order['payment_status'])) ?></span>
                            <small class="admin-cell-sub"><?= e(ucwords(str_replace('_', ' ', $order['order_status']))) ?></small>
                        </td>
                        <td>
                            <div class="admin-order-actions">
                            <?php if ($order['payment_status'] === 'menunggu_verifikasi'): ?>
                                <form method="post" onsubmit="return confirm('Setujui pembayaran pesanan #<?= (int) $order['id'] ?>?')">
                                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                    <button class="admin-button admin-button-success admin-button-sm" name="action" value="approve"><i class="bi bi-check-lg"></i> Setujui</button>
                                </form>
                                <form method="post" onsubmit="return confirm('Tolak bukti pembayaran pesanan ini?')">
                                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                    <button class="admin-button admin-button-danger admin-button-sm" name="action" value="reject"><i class="bi bi-x-lg"></i> Tolak</button>
                                </form>
                            <?php elseif ($order['payment_status'] === 'berhasil' && $order['order_status'] === 'diproses'): ?>
                                <form method="post" onsubmit="return confirm('Tandai pesanan ini sudah dikirim?')">
                                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                    <button class="admin-button admin-button-primary admin-button-sm" name="action" value="ship"><i class="bi bi-truck"></i> Tandai dikirim</button>
                                </form>
                            <?php elseif ($order['payment_status'] === 'berhasil' && $order['order_status'] === 'dikirim'): ?>
                                <form method="post" onsubmit="return confirm('Tandai pesanan ini selesai?')">
                                    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                    <button class="admin-button admin-button-success admin-button-sm" name="action" value="complete"><i class="bi bi-check-circle"></i> Selesaikan</button>
                                </form>
                            <?php else: ?><span class="text-muted">-</span><?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/footer.php'; ?>
